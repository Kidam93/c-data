/*
editeur.h
---------

Par mateo21, pour Le Site du Z�r0 (www.siteduzero.com)

R�le : prototypes des fonctions de gestion de l'�diteur de niveaux.
*/

#ifndef DEF_EDITEUR
#define DEF_EDITEUR

    void editeur(SDL_Surface* ecran);

#endif
