/*
fichiers.h
----------

Par mateo21, pour Le Site du Z�r0 (www.siteduzero.com)

R�le : prototypes des fonctions de lecture / �criture de fichiers de niveau.
*/

#ifndef DEF_FICHIERS
#define DEF_FICHIERS

    int chargerNiveau(int niveau[][NB_BLOCS_HAUTEUR]);
    int sauvegarderNiveau(int niveau[][NB_BLOCS_HAUTEUR]);

#endif

